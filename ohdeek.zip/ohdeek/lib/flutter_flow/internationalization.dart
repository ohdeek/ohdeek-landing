import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['ar', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? arText = '',
    String? enText = '',
  }) =>
      [arText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    'ir5o9s31': {
      'ar': 'Home',
      'en': '',
    },
  },
  // Miscellaneous
  {
    'eu9e7302': {
      'ar': '',
      'en': '',
    },
    '6j26ltvx': {
      'ar': '',
      'en': '',
    },
    'jibg7r8m': {
      'ar': '',
      'en': '',
    },
    '31ko1t2t': {
      'ar': '',
      'en': '',
    },
    '3z8o19ui': {
      'ar': '',
      'en': '',
    },
    '985cigbp': {
      'ar': '',
      'en': '',
    },
    'fwxqgst8': {
      'ar': '',
      'en': '',
    },
    'qfc48yn9': {
      'ar': '',
      'en': '',
    },
    'nmh2tis0': {
      'ar': '',
      'en': '',
    },
    'f4n8yy2m': {
      'ar': '',
      'en': '',
    },
    'w47wmp43': {
      'ar': '',
      'en': '',
    },
    'ztvw1t29': {
      'ar': '',
      'en': '',
    },
    'kn81bwt5': {
      'ar': '',
      'en': '',
    },
    '1z05z9ob': {
      'ar': '',
      'en': '',
    },
    'ttuofpgf': {
      'ar': '',
      'en': '',
    },
    '4akb9c8b': {
      'ar': '',
      'en': '',
    },
    'x1h2m9ew': {
      'ar': '',
      'en': '',
    },
    'svq8mhpn': {
      'ar': '',
      'en': '',
    },
    '3ti35cl7': {
      'ar': '',
      'en': '',
    },
    'udebcdll': {
      'ar': '',
      'en': '',
    },
    'ljfvtuw3': {
      'ar': '',
      'en': '',
    },
    'gji4e5zg': {
      'ar': '',
      'en': '',
    },
    'bp1drd6y': {
      'ar': '',
      'en': '',
    },
    'c5jtguja': {
      'ar': '',
      'en': '',
    },
    'dxuscur8': {
      'ar': '',
      'en': '',
    },
  },
].reduce((a, b) => a..addAll(b));
