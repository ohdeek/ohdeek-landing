// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OptionItemStruct extends BaseStruct {
  OptionItemStruct({
    int? id,
    String? idString,
    String? englishTerm,
    String? arabicTerm,
    String? englishDescription,
    String? arabicDescription,
    Color? mainColor,
    String? iconName,
    String? iconUrl,
    String? backgroundImageUrl,
  })  : _id = id,
        _idString = idString,
        _englishTerm = englishTerm,
        _arabicTerm = arabicTerm,
        _englishDescription = englishDescription,
        _arabicDescription = arabicDescription,
        _mainColor = mainColor,
        _iconName = iconName,
        _iconUrl = iconUrl,
        _backgroundImageUrl = backgroundImageUrl;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "id_string" field.
  String? _idString;
  String get idString => _idString ?? '';
  set idString(String? val) => _idString = val;

  bool hasIdString() => _idString != null;

  // "english_term" field.
  String? _englishTerm;
  String get englishTerm => _englishTerm ?? '';
  set englishTerm(String? val) => _englishTerm = val;

  bool hasEnglishTerm() => _englishTerm != null;

  // "arabic_term" field.
  String? _arabicTerm;
  String get arabicTerm => _arabicTerm ?? '';
  set arabicTerm(String? val) => _arabicTerm = val;

  bool hasArabicTerm() => _arabicTerm != null;

  // "english_description" field.
  String? _englishDescription;
  String get englishDescription => _englishDescription ?? '';
  set englishDescription(String? val) => _englishDescription = val;

  bool hasEnglishDescription() => _englishDescription != null;

  // "arabic_description" field.
  String? _arabicDescription;
  String get arabicDescription => _arabicDescription ?? '';
  set arabicDescription(String? val) => _arabicDescription = val;

  bool hasArabicDescription() => _arabicDescription != null;

  // "main_color" field.
  Color? _mainColor;
  Color? get mainColor => _mainColor;
  set mainColor(Color? val) => _mainColor = val;

  bool hasMainColor() => _mainColor != null;

  // "icon_name" field.
  String? _iconName;
  String get iconName => _iconName ?? '';
  set iconName(String? val) => _iconName = val;

  bool hasIconName() => _iconName != null;

  // "icon_url" field.
  String? _iconUrl;
  String get iconUrl => _iconUrl ?? '';
  set iconUrl(String? val) => _iconUrl = val;

  bool hasIconUrl() => _iconUrl != null;

  // "background_image_url" field.
  String? _backgroundImageUrl;
  String get backgroundImageUrl => _backgroundImageUrl ?? '';
  set backgroundImageUrl(String? val) => _backgroundImageUrl = val;

  bool hasBackgroundImageUrl() => _backgroundImageUrl != null;

  static OptionItemStruct fromMap(Map<String, dynamic> data) =>
      OptionItemStruct(
        id: castToType<int>(data['id']),
        idString: data['id_string'] as String?,
        englishTerm: data['english_term'] as String?,
        arabicTerm: data['arabic_term'] as String?,
        englishDescription: data['english_description'] as String?,
        arabicDescription: data['arabic_description'] as String?,
        mainColor: getSchemaColor(data['main_color']),
        iconName: data['icon_name'] as String?,
        iconUrl: data['icon_url'] as String?,
        backgroundImageUrl: data['background_image_url'] as String?,
      );

  static OptionItemStruct? maybeFromMap(dynamic data) => data is Map
      ? OptionItemStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'id_string': _idString,
        'english_term': _englishTerm,
        'arabic_term': _arabicTerm,
        'english_description': _englishDescription,
        'arabic_description': _arabicDescription,
        'main_color': _mainColor,
        'icon_name': _iconName,
        'icon_url': _iconUrl,
        'background_image_url': _backgroundImageUrl,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'id_string': serializeParam(
          _idString,
          ParamType.String,
        ),
        'english_term': serializeParam(
          _englishTerm,
          ParamType.String,
        ),
        'arabic_term': serializeParam(
          _arabicTerm,
          ParamType.String,
        ),
        'english_description': serializeParam(
          _englishDescription,
          ParamType.String,
        ),
        'arabic_description': serializeParam(
          _arabicDescription,
          ParamType.String,
        ),
        'main_color': serializeParam(
          _mainColor,
          ParamType.Color,
        ),
        'icon_name': serializeParam(
          _iconName,
          ParamType.String,
        ),
        'icon_url': serializeParam(
          _iconUrl,
          ParamType.String,
        ),
        'background_image_url': serializeParam(
          _backgroundImageUrl,
          ParamType.String,
        ),
      }.withoutNulls;

  static OptionItemStruct fromSerializableMap(Map<String, dynamic> data) =>
      OptionItemStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        idString: deserializeParam(
          data['id_string'],
          ParamType.String,
          false,
        ),
        englishTerm: deserializeParam(
          data['english_term'],
          ParamType.String,
          false,
        ),
        arabicTerm: deserializeParam(
          data['arabic_term'],
          ParamType.String,
          false,
        ),
        englishDescription: deserializeParam(
          data['english_description'],
          ParamType.String,
          false,
        ),
        arabicDescription: deserializeParam(
          data['arabic_description'],
          ParamType.String,
          false,
        ),
        mainColor: deserializeParam(
          data['main_color'],
          ParamType.Color,
          false,
        ),
        iconName: deserializeParam(
          data['icon_name'],
          ParamType.String,
          false,
        ),
        iconUrl: deserializeParam(
          data['icon_url'],
          ParamType.String,
          false,
        ),
        backgroundImageUrl: deserializeParam(
          data['background_image_url'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'OptionItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is OptionItemStruct &&
        id == other.id &&
        idString == other.idString &&
        englishTerm == other.englishTerm &&
        arabicTerm == other.arabicTerm &&
        englishDescription == other.englishDescription &&
        arabicDescription == other.arabicDescription &&
        mainColor == other.mainColor &&
        iconName == other.iconName &&
        iconUrl == other.iconUrl &&
        backgroundImageUrl == other.backgroundImageUrl;
  }

  @override
  int get hashCode => const ListEquality().hash([
        id,
        idString,
        englishTerm,
        arabicTerm,
        englishDescription,
        arabicDescription,
        mainColor,
        iconName,
        iconUrl,
        backgroundImageUrl
      ]);
}

OptionItemStruct createOptionItemStruct({
  int? id,
  String? idString,
  String? englishTerm,
  String? arabicTerm,
  String? englishDescription,
  String? arabicDescription,
  Color? mainColor,
  String? iconName,
  String? iconUrl,
  String? backgroundImageUrl,
}) =>
    OptionItemStruct(
      id: id,
      idString: idString,
      englishTerm: englishTerm,
      arabicTerm: arabicTerm,
      englishDescription: englishDescription,
      arabicDescription: arabicDescription,
      mainColor: mainColor,
      iconName: iconName,
      iconUrl: iconUrl,
      backgroundImageUrl: backgroundImageUrl,
    );
