import '../database.dart';

class CategorizeGiftsTable extends SupabaseTable<CategorizeGiftsRow> {
  @override
  String get tableName => 'categorize_gifts';

  @override
  CategorizeGiftsRow createRow(Map<String, dynamic> data) =>
      CategorizeGiftsRow(data);
}

class CategorizeGiftsRow extends SupabaseDataRow {
  CategorizeGiftsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => CategorizeGiftsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get idString => getField<String>('id_string');
  set idString(String? value) => setField<String>('id_string', value);

  String? get englishTerm => getField<String>('english_term');
  set englishTerm(String? value) => setField<String>('english_term', value);

  String? get arabicTerm => getField<String>('arabic_term');
  set arabicTerm(String? value) => setField<String>('arabic_term', value);

  String? get mainColor => getField<String>('main_color');
  set mainColor(String? value) => setField<String>('main_color', value);

  String? get iconName => getField<String>('icon_name');
  set iconName(String? value) => setField<String>('icon_name', value);

  String? get backgroundImageUrl => getField<String>('background_image_url');
  set backgroundImageUrl(String? value) =>
      setField<String>('background_image_url', value);

  int? get level => getField<int>('level');
  set level(int? value) => setField<int>('level', value);

  bool? get active => getField<bool>('active');
  set active(bool? value) => setField<bool>('active', value);
}
