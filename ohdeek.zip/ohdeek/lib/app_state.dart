import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<OptionItemStruct> _MainOptions = [
    OptionItemStruct.fromSerializableMap(jsonDecode(
        '{\"id_int\":\"0\",\"id_string\":\"Hello World\",\"english_term\":\"Hello World\",\"arabic_term\":\"Hello World\",\"english_description\":\"Hello World\",\"arabic_description\":\"Hello World\",\"main_color\":\"#0000\",\"icon_name\":\"Hello World\"}')),
    OptionItemStruct.fromSerializableMap(jsonDecode(
        '{\"id_int\":\"0\",\"id_string\":\"Hello World\",\"english_term\":\"Hello World\",\"arabic_term\":\"Hello World\",\"english_description\":\"Hello World\",\"arabic_description\":\"Hello World\",\"main_color\":\"#0000\",\"icon_name\":\"Hello World\"}')),
    OptionItemStruct.fromSerializableMap(jsonDecode(
        '{\"id_int\":\"0\",\"id_string\":\"Hello World\",\"english_term\":\"Hello World\",\"arabic_term\":\"Hello World\",\"english_description\":\"Hello World\",\"arabic_description\":\"Hello World\",\"main_color\":\"#0000\",\"icon_name\":\"Hello World\"}')),
    OptionItemStruct.fromSerializableMap(jsonDecode(
        '{\"id_int\":\"0\",\"id_string\":\"Hello World\",\"english_term\":\"Hello World\",\"arabic_term\":\"Hello World\",\"english_description\":\"Hello World\",\"arabic_description\":\"Hello World\",\"main_color\":\"#0000\",\"icon_name\":\"Hello World\"}'))
  ];
  List<OptionItemStruct> get MainOptions => _MainOptions;
  set MainOptions(List<OptionItemStruct> value) {
    _MainOptions = value;
  }

  void addToMainOptions(OptionItemStruct value) {
    MainOptions.add(value);
  }

  void removeFromMainOptions(OptionItemStruct value) {
    MainOptions.remove(value);
  }

  void removeAtIndexFromMainOptions(int index) {
    MainOptions.removeAt(index);
  }

  void updateMainOptionsAtIndex(
    int index,
    OptionItemStruct Function(OptionItemStruct) updateFn,
  ) {
    MainOptions[index] = updateFn(_MainOptions[index]);
  }

  void insertAtIndexInMainOptions(int index, OptionItemStruct value) {
    MainOptions.insert(index, value);
  }
}
