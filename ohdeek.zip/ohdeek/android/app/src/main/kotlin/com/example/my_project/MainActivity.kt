package com.ohdeek.landing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
